public class SavingsAccount extends BankAccount {
  
  private double interestRate = 0.005;
  
  public SavingsAccount( double initialAmount) {
    
    super( initialAmount);
    
  }
  
  public void addPeriodicInterest() {
   
    double interestAmount = super.balance * this.interestRate;
    
    super.deposit( interestAmount);
    
  }
  
  public String toString() {
   
    return ("Savings " + super.toString());
    
  }
  
  
  
  
  
  
  
  
  
  
  
}