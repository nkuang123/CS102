/**
 * Class CharStack implements a stack of Characters
 */
package lab5;

/**
 *
 * @author write your name here
 */
public class CharStack implements Stackable{
    
}
