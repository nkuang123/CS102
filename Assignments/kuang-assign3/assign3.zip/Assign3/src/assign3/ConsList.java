package assign3;

/**
 * class ConsList: representation of a non-empty list of integers
 * @author write your name here
 */
public class ConsList implements IList{
    
    // private instance variables
    private int first;
    private IList rest;
    
    /**
     * Constructor for objects of type ConsList
     * @param first is an int
     * @param rest is an IList 
     */
    public ConsList(int first, IList rest){
        this.first = first;
        this.rest = rest;
    }
    /**
     * length 
     * @return int holding length of this list 
     */
    public int length() {
        return 1 + this.rest.length();
    }
    /**
     * sum 
     * @return int holding sum of all number in this 
     * list 
     */
    public int sum() {
        return this.first + this.rest.sum();
    }
    /**
     * toString
     * @return string representation of this list
     */
    public String toString() {
        // Returns string representation of this list
        return "" + this.first + " " + this.rest;
    }
    
}
