package assign3;

/**
 * class MTList: Representation of an empty list of integers
 * @author write your name here
 */
public class MTList implements IList {
    
    /** 
     * length
     * @return int length of this empty list
     */
    public int length() {
        return 0;
    }
    
    /**
     * sum
     * @return int representing sum of the numbers in 
     * this empty list
     */
    public int sum() {
        return 0;
    }
    
    /**
     * toString 
     * @return String representation of empty list
     */
    public String toString() {
        return "";
    }   
}
